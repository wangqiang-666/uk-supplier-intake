/**
 * SQLite schema (multi-source ready).
 *
 * We start with SRA Data Sharing API organisations.
 * Other sources can be added by inserting rows into `sources` and writing new ingesters.
 */

function initSchema(db) {
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS sources (
      code        TEXT PRIMARY KEY,
      name        TEXT NOT NULL,
      country     TEXT NOT NULL,
      website     TEXT,
      created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS runs (
      run_id        TEXT PRIMARY KEY,
      source        TEXT NOT NULL REFERENCES sources(code),
      started_at    TEXT NOT NULL,
      finished_at   TEXT,
      org_total     INTEGER DEFAULT 0,
      org_kept      INTEGER DEFAULT 0,
      config        TEXT
    );

    CREATE TABLE IF NOT EXISTS organisations (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      source          TEXT NOT NULL REFERENCES sources(code),
      external_id     TEXT NOT NULL,
      name            TEXT NOT NULL,
      authorisation_status TEXT DEFAULT '',
      organisation_type    TEXT DEFAULT '',
      work_areas       TEXT DEFAULT '[]', -- JSON array

      address_line1    TEXT DEFAULT '',
      address_line2    TEXT DEFAULT '',
      address_line3    TEXT DEFAULT '',
      city             TEXT DEFAULT '',
      county           TEXT DEFAULT '',
      postcode         TEXT DEFAULT '',
      country          TEXT DEFAULT '',
      telephone        TEXT DEFAULT '',
      email            TEXT DEFAULT '',
      website          TEXT DEFAULT '',
      office_type      TEXT DEFAULT '',

      source_url       TEXT DEFAULT '',
      raw_json         TEXT DEFAULT '{}',

      first_seen_run   TEXT NOT NULL,
      last_seen_run    TEXT NOT NULL,
      created_at       TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at       TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),

      email_sent       INTEGER NOT NULL DEFAULT 0,
      email_sent_at    TEXT,
      email_send_count INTEGER NOT NULL DEFAULT 0,

      apostille_qualified INTEGER NOT NULL DEFAULT 0, -- 海牙认证资质: 1=有, 0=无/未知

      UNIQUE(source, external_id)
    );

    CREATE INDEX IF NOT EXISTS idx_org_source     ON organisations(source);
    CREATE INDEX IF NOT EXISTS idx_org_name       ON organisations(name);
    CREATE INDEX IF NOT EXISTS idx_org_email_sent ON organisations(email_sent);
  `);

  const insert = db.prepare(`
    INSERT OR IGNORE INTO sources (code, name, country, website)
    VALUES (@code, @name, @country, @website)
  `);

  insert.run({
    code: "sra_api",
    name: "SRA Data Sharing API",
    country: "GB",
    website: "https://sra-prod-apim.azure-api.net",
  });

  insert.run({
    code: "facultyoffice",
    name: "The Faculty Office (NotaryPRO)",
    country: "GB",
    website: "https://notarypro.facultyoffice.org.uk",
  });

  insert.run({
    code: "lawsociety_scraper",
    name: "The Law Society (Find a Solicitor)",
    country: "GB",
    website: "https://solicitors.lawsociety.org.uk",
  });
}

module.exports = { initSchema };

