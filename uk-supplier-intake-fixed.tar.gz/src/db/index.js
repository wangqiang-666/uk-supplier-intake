const Database = require("better-sqlite3");
const path = require("node:path");
const { initSchema } = require("./schema");

/** Repo root (uk-supplier-intake/), not process.cwd() — avoids PM2/cron opening the wrong file */
const PROJECT_ROOT = path.join(__dirname, "..", "..");
const DEFAULT_DB_FULL = path.join(PROJECT_ROOT, "data", "supplier-intake.db");

let _db = null;

function resolveDbFull(dbPath) {
  if (dbPath) {
    return path.isAbsolute(dbPath) ? dbPath : path.resolve(process.cwd(), dbPath);
  }
  const env = process.env.DB_PATH;
  if (env) {
    return path.isAbsolute(env) ? env : path.resolve(PROJECT_ROOT, env);
  }
  return DEFAULT_DB_FULL;
}

function getDb(dbPath) {
  if (_db) return _db;
  const full = resolveDbFull(dbPath);
  _db = new Database(full);
  initSchema(_db);
  return _db;
}

function closeDb() {
  if (_db) _db.close();
  _db = null;
}

function insertRun(db, run) {
  db.prepare(`
    INSERT INTO runs (run_id, source, started_at, config)
    VALUES (@run_id, @source, @started_at, @config)
  `).run(run);
}

function finishRun(db, run) {
  db.prepare(`
    UPDATE runs SET
      finished_at = @finished_at,
      org_total = @org_total,
      org_kept = @org_kept
    WHERE run_id = @run_id
  `).run(run);
}

function upsertOrganisation(db, org, runId) {
  const existing = db
    .prepare("SELECT id FROM organisations WHERE source = ? AND external_id = ?")
    .get(org.source, org.external_id);

  const payload = {
    ...org,
    work_areas: JSON.stringify(org.work_areas || []),
    raw_json: JSON.stringify(org.raw_json || {}),
    apostille_qualified: org.apostille_qualified || 0,
    run_id: runId,
  };

  if (existing) {
    db.prepare(`
      UPDATE organisations SET
        name = @name,
        authorisation_status = @authorisation_status,
        organisation_type = @organisation_type,
        work_areas = @work_areas,
        address_line1 = @address_line1,
        address_line2 = @address_line2,
        address_line3 = @address_line3,
        city = @city,
        county = @county,
        postcode = @postcode,
        country = @country,
        telephone = @telephone,
        email = @email,
        website = @website,
        office_type = @office_type,
        source_url = @source_url,
        raw_json = @raw_json,
        apostille_qualified = @apostille_qualified,
        last_seen_run = @run_id,
        updated_at = datetime('now', 'localtime')
      WHERE id = @id
    `).run({ ...payload, id: existing.id });
    return existing.id;
  }

  const res = db.prepare(`
    INSERT INTO organisations (
      source, external_id, name, authorisation_status, organisation_type, work_areas,
      address_line1, address_line2, address_line3, city, county, postcode, country,
      telephone, email, website, office_type,
      source_url, raw_json, apostille_qualified,
      first_seen_run, last_seen_run
    ) VALUES (
      @source, @external_id, @name, @authorisation_status, @organisation_type, @work_areas,
      @address_line1, @address_line2, @address_line3, @city, @county, @postcode, @country,
      @telephone, @email, @website, @office_type,
      @source_url, @raw_json, @apostille_qualified,
      @run_id, @run_id
    )
  `).run(payload);

  return res.lastInsertRowid;
}

function listSources(db) {
  return db.prepare("SELECT * FROM sources ORDER BY code").all();
}

function listRuns(db, limit = 20, source) {
  if (source) {
    return db.prepare("SELECT * FROM runs WHERE source = ? ORDER BY started_at DESC LIMIT ?").all(source, limit);
  }
  return db.prepare("SELECT * FROM runs ORDER BY started_at DESC LIMIT ?").all(limit);
}

module.exports = {
  getDb,
  closeDb,
  insertRun,
  finishRun,
  upsertOrganisation,
  listSources,
  listRuns,
};

