require("dotenv").config();

const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const path = require("node:path");

const { getDb, closeDb, listSources, listRuns } = require("./db");

const PORT = Number(process.env.PORT || "3000");
const app = express();

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 120 }));
app.use(express.static(path.resolve("public")));

function json(res, data, status = 200) {
  res.status(status).json(data);
}

const ORG_SORT = new Set(["id", "name", "external_id", "postcode", "city", "country", "source", "apostille_qualified", "created_at", "updated_at"]);

app.get("/api/sources", (req, res) => {
  const db = getDb();
  json(res, listSources(db));
});

app.get("/api/runs", (req, res) => {
  const db = getDb();
  const source = req.query.source ? String(req.query.source) : undefined;
  json(res, listRuns(db, 30, source));
});

app.get("/api/next-updates", (req, res) => {
  const db = getDb();
  // 获取每个数据源最后一次成功运行的时间
  const sources = [
    { code: "sra_api", label: "SRA", cron: "weekly_mon_2" },
    { code: "lawsociety_scraper", label: "Law Society", cron: "daily_3" },
    { code: "facultyoffice", label: "Faculty Office", cron: "weekly_mon_4" },
  ];
  const result = [];
  for (const s of sources) {
    const lastRun = db.prepare(
      "SELECT started_at, finished_at FROM runs WHERE source = ? AND finished_at IS NOT NULL ORDER BY started_at DESC LIMIT 1"
    ).get(s.code);
    result.push({
      source: s.code,
      label: s.label,
      cron: s.cron,
      last_run: lastRun ? lastRun.finished_at || lastRun.started_at : null,
    });
  }
  json(res, result);
});

app.get("/api/organisations", (req, res) => {
  const db = getDb();

  const page = Math.max(1, Number(req.query.page || "1"));
  const pageSize = Math.min(200, Math.max(1, Number(req.query.pageSize || "50")));
  const sort = ORG_SORT.has(String(req.query.sort)) ? String(req.query.sort) : "id";
  const order = String(req.query.order) === "desc" ? "DESC" : "ASC";

  const conditions = [];
  const params = [];

  const source = req.query.source ? String(req.query.source) : "";
  if (source) {
    conditions.push("source = ?");
    params.push(source);
  }

  const search = req.query.search ? String(req.query.search).trim() : "";
  if (search && search.length >= 2) {
    conditions.push("(name LIKE ? OR external_id LIKE ? OR email LIKE ? OR postcode LIKE ? OR city LIKE ?)");
    const like = `%${search}%`;
    params.push(like, like, like, like, like);
  }

  const where = conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";
  const total = db.prepare(`SELECT COUNT(*) AS c FROM organisations ${where}`).get(...params).c;
  const offset = (page - 1) * pageSize;
  const rows = db
    .prepare(`SELECT * FROM organisations ${where} ORDER BY ${sort} ${order} LIMIT ? OFFSET ?`)
    .all(...params, pageSize, offset);

  json(res, { total, page, pageSize, totalPages: Math.ceil(total / pageSize), rows });
});

app.get("/api/stats", (req, res) => {
  const db = getDb();
  const source = req.query.source ? String(req.query.source) : "";
  const where = source ? "WHERE source = ?" : "";
  const params = source ? [source] : [];

  const orgs = db.prepare(`SELECT COUNT(*) AS c FROM organisations ${where}`).get(...params).c;
  const lastRun = source
    ? db.prepare("SELECT * FROM runs WHERE source = ? ORDER BY started_at DESC LIMIT 1").get(source)
    : db.prepare("SELECT * FROM runs ORDER BY started_at DESC LIMIT 1").get();

  json(res, { organisations: orgs, lastRun: lastRun || null });
});

app.get("/api/email-stats", (req, res) => {
  const db = getDb();
  const source = req.query.source ? String(req.query.source) : "";
  const where = source ? "WHERE source = ? AND email_sent = ?" : "WHERE email_sent = ?";
  const params = source ? [source, 1] : [1];
  const paramsUnsent = source ? [source, 0] : [0];

  const sent = db.prepare(`SELECT COUNT(*) AS c FROM organisations ${where}`).get(...params).c;
  const unsent = db.prepare(`SELECT COUNT(*) AS c FROM organisations ${where}`).get(...paramsUnsent).c;

  json(res, { sent, unsent });
});

app.get("/api/quality-stats", (req, res) => {
  const db = getDb();
  const source = req.query.source ? String(req.query.source) : "";
  const where = source ? "WHERE source = ?" : "";
  const params = source ? [source] : [];

  const total = db.prepare(`SELECT COUNT(*) AS c FROM organisations ${where}`).get(...params).c;

  // 字段完整度
  const fields = ["email", "postcode", "city", "telephone", "website", "authorisation_status"];
  const completeness = {};
  for (const f of fields) {
    const andWhere = where ? `${where} AND` : "WHERE";
    const filled = db.prepare(
      `SELECT COUNT(*) AS c FROM organisations ${andWhere} ${f} != '' AND ${f} IS NOT NULL`
    ).get(...params).c;
    completeness[f] = total > 0 ? Math.round((filled / total) * 100) : 0;
  }

  // work_areas 非空
  const andWhere2 = where ? `${where} AND` : "WHERE";
  const withWorkAreas = db.prepare(
    `SELECT COUNT(*) AS c FROM organisations ${andWhere2} work_areas != '[]' AND work_areas != ''`
  ).get(...params).c;
  completeness.work_areas = total > 0 ? Math.round((withWorkAreas / total) * 100) : 0;

  // 各数据源明细
  const perSource = db.prepare(`
    SELECT source, COUNT(*) as total,
      SUM(CASE WHEN email != '' AND email IS NOT NULL THEN 1 ELSE 0 END) as has_email,
      SUM(CASE WHEN postcode != '' AND postcode IS NOT NULL THEN 1 ELSE 0 END) as has_postcode,
      SUM(CASE WHEN city != '' AND city IS NOT NULL THEN 1 ELSE 0 END) as has_city,
      SUM(CASE WHEN telephone != '' AND telephone IS NOT NULL THEN 1 ELSE 0 END) as has_telephone,
      SUM(CASE WHEN work_areas != '[]' AND work_areas != '' AND work_areas IS NOT NULL THEN 1 ELSE 0 END) as has_work_areas
    FROM organisations ${where}
    GROUP BY source
  `).all(...params);

  json(res, { total, completeness, perSource });
});

// ──────────────────────────────────────────────
// OpenClaw 邮件接口（统一入口）
// POST /api/email/action
// Body: { action: "query" | "send", count: 10, source?: "sra_api" }
// action=query: 只查询，不标记
// action=send: 查询并标记为已发送
// ──────────────────────────────────────────────
app.post("/api/email/action", (req, res) => {
  const db = getDb();

  const { action, count, source } = req.body || {};

  // 参数校验
  if (!action || !["query", "send"].includes(action)) {
    return json(res, { error: "action must be 'query' or 'send'" }, 400);
  }

  const limit = Math.min(200, Math.max(1, Number(count) || 10));

  // 构建查询：只取有 email 且未发送的记录
  const conditions = ["email_sent = 0", "email != ''", "email IS NOT NULL"];
  const params = [];

  if (source) {
    conditions.push("source = ?");
    params.push(String(source));
  }

  const where = `WHERE ${conditions.join(" AND ")}`;

  // 查出待发送记录
  const rows = db
    .prepare(
      `SELECT id, source, external_id, name, email, telephone, city, postcode,
              organisation_type, work_areas, apostille_qualified, website
       FROM organisations ${where}
       ORDER BY id ASC LIMIT ?`
    )
    .all(...params, limit);

  // 如果是 send 动作，标记为已发送
  if (action === "send" && rows.length > 0) {
    const now = new Date().toISOString().replace("T", " ").slice(0, 19);
    const ids = rows.map((r) => r.id);
    const placeholders = ids.map(() => "?").join(",");

    db.prepare(
      `UPDATE organisations
       SET email_sent = 1,
           email_sent_at = ?,
           email_send_count = email_send_count + 1,
           updated_at = datetime('now', 'localtime')
       WHERE id IN (${placeholders})`
    ).run(now, ...ids);

    json(res, { action, count: rows.length, rows, marked_as_sent: true });
  } else {
    json(res, { action, count: rows.length, rows });
  }
});

app.get("/api/export-orgs", (req, res) => {
  const db = getDb();

  const conditions = [];
  const params = [];

  const source = req.query.source ? String(req.query.source) : "";
  if (source) {
    conditions.push("source = ?");
    params.push(source);
  }

  const search = req.query.search ? String(req.query.search).trim() : "";
  if (search && search.length >= 2) {
    conditions.push("(name LIKE ? OR external_id LIKE ? OR email LIKE ? OR postcode LIKE ? OR city LIKE ?)");
    const like = `%${search}%`;
    params.push(like, like, like, like, like);
  }

  const where = conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";
  const rows = db.prepare(`SELECT * FROM organisations ${where} ORDER BY id`).all(...params);
  if (rows.length === 0) {
    res.status(200).type("text/plain").send("No data");
    return;
  }

  const headers = Object.keys(rows[0]);
  const lines = [];
  lines.push(headers.join(","));
  for (const r of rows) {
    lines.push(
      headers
        .map((h) => {
          const v = r[h];
          const s = v == null ? "" : String(v);
          if (/[\",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
          return s;
        })
        .join(","),
    );
  }

  const filename = `organisations_${new Date().toISOString().slice(0, 10)}.csv`;
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.send("\uFEFF" + lines.join("\n"));
});

app.listen(PORT, () => {
  console.log(`Web server running at http://localhost:${PORT}`);
  console.log(`Tip: run "npm run ingest" first to load SRA organisations into SQLite.`);
});

process.on("SIGINT", () => {
  closeDb();
  process.exit(0);
});

